import { useRouter } from 'next/router';
import { useState } from 'react';
import Link from 'next/link';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();

    // Debugging - log the entered values to check
    console.log("Submitted Email:", email);
    console.log("Submitted Password:", password);

    // Remove spaces from the email and password before comparing
    const trimmedEmail = email.trim();
    const trimmedPassword = password.trim();

    // Dummy validation (email and password must match exactly)
    if (trimmedEmail === 'rawatakshat9412@gmail.com' && trimmedPassword === 'Credit@5460') {
      console.log("Login successful, redirecting to welcome page...");
      router.push('/welcome'); // Redirect to welcome page
    } else {
      console.log("Invalid credentials - either email or password is incorrect");
      alert('Invalid credentials');
    }
  };

  return (
    <div 
      className="flex items-center justify-center min-h-screen bg-cover bg-center" 
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1517261732412-2e88db6bdfb9")',
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="bg-white bg-opacity-80 p-8 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-3xl font-semibold mb-6 text-center text-gray-800">Login to Your Account</h2>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your email"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 mt-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your password"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-300"
          >
            Login
          </button>
        </form>

        {/* Footer with Register Link */}
        <div className="mt-4 text-center">
  <p className="text-sm">
    Don't have an account?{' '}
    <Link href="/register" className="text-blue-600 hover:underline">
      Register
    </Link>
  </p>
</div>

      </div>
    </div>
  );
}
