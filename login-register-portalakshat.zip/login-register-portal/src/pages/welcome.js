// pages/welcome.js
import Link from 'next/link';

export default function Welcome() {
  return (
    <div
      className="flex items-center justify-center min-h-screen bg-cover bg-center"
      style={{
        backgroundImage: 'url("https://plus.unsplash.com/premium_photo-1677572452964-91e968d02d6a?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D")', // A beautiful landscape image from Unsplash
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        backgroundAttachment: 'fixed', // Optional, to keep the background fixed while scrolling
      }}
    >
      <div className="bg-white bg-opacity-70 p-10 rounded-lg text-center text-Purple">
        <h1 className="text-4xl font-bold mb-4">Welcome to Buddy4Study</h1>
        <p className="text-lg">Gateway to scholarship world</p>
        
        {/* Link back to Register */}
        <div className="mt-4 text-center">
          <p className="text-sm">
            Don't have an account?{' '}
            <Link href="/register" className="text-blue-600 hover:underline">
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
